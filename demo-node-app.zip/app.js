const express = require("express");
const app = express();
const port = process.env.PORT || 3000;

app.get("/", (req, res) => {
  res.send("Hello from Demo Node.js App on EC2!");
});

app.listen(port, "0.0.0.0", () => {
  console.log(`Demo app running on port ${port}`);
});
